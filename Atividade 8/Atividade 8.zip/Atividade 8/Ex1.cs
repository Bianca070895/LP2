﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class Ex1 : Form
    {
        public Ex1()
        {
            InitializeComponent();
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int contadorEspacos = 0;

            foreach (char c in frase)
            {
                if (c == ' ')
                {
                    contadorEspacos++;
                }
            }

            MessageBox.Show($"Número de espaços em branco na frase: {contadorEspacos}");
      
    }

        private void btnR_Click(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int contadorR = 0;

            foreach (char c in frase)
            {
                if (c == 'R' || c == 'r')
                {
                    contadorR++;
                }
            }

            MessageBox.Show($"Número de vezes que a letra 'R' aparece na frase: {contadorR}");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int contadorPares = 0;

            for (int i = 0; i < frase.Length - 1; i++)
            {
                if (frase[i] == frase[i + 1])
                {
                    contadorPares++;
                }
            }

            MessageBox.Show($"Número de pares de letras iguais na frase: {contadorPares}");
        
        }

        private void btnEspaco_Click_1(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int contadorEspacos = 0;

            foreach (char c in frase)
            {
                if (c == ' ')
                {
                    contadorEspacos++;
                }
            }

            MessageBox.Show($"Número de espaços em branco na frase: {contadorEspacos}");
        }

        private void btnR_Click_1(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int contadorR = 0;

            foreach (char c in frase)
            {
                if (c == 'R' || c == 'r')
                {
                    contadorR++;
                }
            }

            MessageBox.Show($"Número de vezes que a letra 'R' aparece na frase: {contadorR}");
        }

        private void btnLetras_Click_1(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int contadorPares = 0;

            for (int i = 0; i < frase.Length - 1; i++)
            {
                if (frase[i] == frase[i + 1])
                {
                    contadorPares++;
                }
            }

            MessageBox.Show($"Número de pares de letras iguais na frase: {contadorPares}");

        }
    }
}