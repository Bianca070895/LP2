﻿namespace Atividade_8
{
    partial class Ex1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(89, 39);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(552, 105);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // btnEspaco
            // 
            this.btnEspaco.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEspaco.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspaco.Location = new System.Drawing.Point(90, 182);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(144, 89);
            this.btnEspaco.TabIndex = 1;
            this.btnEspaco.Text = "Espaço em Branco";
            this.btnEspaco.UseVisualStyleBackColor = false;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click_1);
            // 
            // btnR
            // 
            this.btnR.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnR.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR.Location = new System.Drawing.Point(295, 181);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(144, 89);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "Vezes Letra R";
            this.btnR.UseVisualStyleBackColor = false;
            this.btnR.Click += new System.EventHandler(this.btnR_Click_1);
            // 
            // btnLetras
            // 
            this.btnLetras.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetras.Location = new System.Drawing.Point(497, 182);
            this.btnLetras.Name = "btnLetras";
            this.btnLetras.Size = new System.Drawing.Size(144, 89);
            this.btnLetras.TabIndex = 3;
            this.btnLetras.Text = "Ocorre um mesmo par de letras";
            this.btnLetras.UseVisualStyleBackColor = false;
            this.btnLetras.Click += new System.EventHandler(this.btnLetras_Click_1);
            // 
            // Ex1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(723, 333);
            this.Controls.Add(this.btnLetras);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Ex1";
            this.Text = "Ex1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnLetras;
    }
}