﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class Ex3 : Form
    {
        public Ex3()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string fraseOriginal = txtVerificar.Text.ToUpper(); 
            string fraseSemEspacos = RemoverEspacos(fraseOriginal);

            if (ÉPalíndromo(fraseSemEspacos))
            {
                MessageBox.Show("A frase é um palíndromo.");
            }
            else
            {
                MessageBox.Show("A frase não é um palíndromo.");
            }
        }

        private string RemoverEspacos(string frase)
        {
            return frase.Replace(" ", "");
        }

        private bool ÉPalíndromo(string frase)
        {
            int i = 0;
            int j = frase.Length - 1;

            while (i < j)
            {
                if (frase[i] != frase[j])
                {
                    return false;
                }
                i++;
                j--;
            }
            return true;
        }
    }
}
