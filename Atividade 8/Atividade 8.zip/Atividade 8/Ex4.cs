﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class Ex4 : Form
    {
        public Ex4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
            {
                
                string nome = txtNome.Text;
                string matricula = txtMatricula.Text;
                int producao = Convert.ToInt32(txtProdução.Text);
                double salarioBase = Convert.ToDouble(txtSalarioBase.Text);
                double gratificacao = Convert.ToDouble(txtGratificacao.Text);

               
                int B = producao >= 100 ? 1 : 0;
                int C = producao >= 120 ? 1 : 0;
                int D = producao >= 150 ? 1 : 0;

                
                double salarioBruto = salarioBase + salarioBase * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

               
                if (salarioBruto > 7000 && (D == 0 || gratificacao == 0))
                {
                    MessageBox.Show("O maior salário bruto a ser pago é R$7.000,00. Valor acima disso só pode ser pago a funcionários com produção >= 150 e que tenham gratificação.");
                }
                else
                {
                    MessageBox.Show($"O salário bruto de {nome} (Matrícula: {matricula}) é R${Math.Min(salarioBruto, 7000):N2}");
                }
            }
        }
    }

