﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_8
{
    public partial class Ex2 : Form
    {
        public Ex2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtCalcular.Text, out int N) && N > 0)
            {
                double H = 1.0;

                for (int i = 2; i <= N; i++)
                {
                    H += 1.0 / i;
                }

                MessageBox.Show($"O número H para N = {N} é {H}");
            }
            else
            {
                MessageBox.Show("Por favor, insira um número válido maior que zero.");
            }
        }
    }
}
