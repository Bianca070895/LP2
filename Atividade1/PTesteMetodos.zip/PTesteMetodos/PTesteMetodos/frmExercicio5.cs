﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            {
                // Verifica se os campos de texto estão vazios
                if (string.IsNullOrWhiteSpace(txtNum1.Text) || string.IsNullOrWhiteSpace(txtNum2.Text))
                {
                    MessageBox.Show("Por favor, insira números em ambos os campos.");
                    return;
                }

                // Converte os valores dos TextBoxes em números
                if (!int.TryParse(txtNum1.Text, out int num1) || !int.TryParse(txtNum2.Text, out int num2))
                {
                    MessageBox.Show("Por favor, insira números válidos em ambos os campos.");
                    return;
                }

                // Verifica se o primeiro número é menor que o segundo número
                if (num1 >= num2)
                {
                    MessageBox.Show("O primeiro número deve ser menor que o segundo número.");
                    return;
                }
                // Realiza o sorteio entre os números
                Random random = new Random();
                int sorteio = random.Next(num1, num2 + 1); // +1 para incluir o segundo número
                MessageBox.Show($"O número sorteado é: {sorteio}");
            }
        }
    }
}
