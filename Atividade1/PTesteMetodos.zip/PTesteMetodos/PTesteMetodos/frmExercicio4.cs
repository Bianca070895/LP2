﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumerico_Click(object sender, EventArgs e)
        {
            int countNumeric = CountNumericCharacters(richTextBox1.Text);
            MessageBox.Show($"Número de caracteres numéricos: {countNumeric}");
        }

        private void btnCaracter_Click(object sender, EventArgs e)
        {
            int firstWhiteSpacePosition = FindFirstWhiteSpacePosition(richTextBox1.Text);
            MessageBox.Show($"Posição do primeiro caractere em branco: {firstWhiteSpacePosition}");
        }

        private void btnQntBranco_Click(object sender, EventArgs e)
        {
            int countAlphabetic = CountAlphabeticCharacters(richTextBox1.Text);
            MessageBox.Show($"Número de caracteres alfabéticos: {countAlphabetic}");
        }
        private int CountNumericCharacters(string text)
        {
            int count = 0;
            foreach (char c in text)
            {
                if (char.IsNumber(c))
                {
                    count++;
                }
            }
            return count;
        }

        private int FindFirstWhiteSpacePosition(string text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                if (char.IsWhiteSpace(text[i]))
                {
                    return i;
                }
            }
            return -1; // Retorna -1 se não encontrar nenhum caractere em branco
        }

        private int CountAlphabeticCharacters(string text)
        {
            int count = 0;
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    count++;
                }
            }
            return count;
        }
    }
}
