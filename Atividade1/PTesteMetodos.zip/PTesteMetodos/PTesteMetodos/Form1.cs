﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");

                // se o formulário não tiver nenhum componente dá erro
                // precisaria testar o controls.Count do form

                //Ou ... Application.OpenForms["frmExercicio2"].BringToFront();

                //Uma opção seria usar o Activate() no lugar do BringToFront()
                // O método Activate() faz basicamente a mesma coisa que o
                // BringToFront com o adicional de dar foco no form.
            }
            else
            {
                frmExercicio4 objfrm2 = new frmExercicio4();
                objfrm2.MdiParent = this;
                objfrm2.WindowState = FormWindowState.Maximized;
                objfrm2.Show();
            }
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("COPIAR");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("COLAR");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                MessageBox.Show("Form já existe");

                // se o formulário não tiver nenhum componente dá erro
                // precisaria testar o controls.Count do form

                //Ou ... Application.OpenForms["frmExercicio2"].BringToFront();

                //Uma opção seria usar o Activate() no lugar do BringToFront()
                // O método Activate() faz basicamente a mesma coisa que o
                // BringToFront com o adicional de dar foco no form.
            }
            else
            {
                frmExercicio2 objfrm2 = new frmExercicio2();
                objfrm2.MdiParent = this;
                objfrm2.WindowState = FormWindowState.Maximized;
                objfrm2.Show();
            }

        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {

                if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
                {
                    MessageBox.Show("Form já existe");

                    // se o formulário não tiver nenhum componente dá erro
                    // precisaria testar o controls.Count do form

                    //Ou ... Application.OpenForms["frmExercicio2"].BringToFront();

                    //Uma opção seria usar o Activate() no lugar do BringToFront()
                    // O método Activate() faz basicamente a mesma coisa que o
                    // BringToFront com o adicional de dar foco no form.
                }
                else
                {
                    frmExercicio3 objfrm2 = new frmExercicio3();
                    objfrm2.MdiParent = this;
                    objfrm2.WindowState = FormWindowState.Maximized;
                    objfrm2.Show();
                }

            }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");

                // se o formulário não tiver nenhum componente dá erro
                // precisaria testar o controls.Count do form

                //Ou ... Application.OpenForms["frmExercicio2"].BringToFront();

                //Uma opção seria usar o Activate() no lugar do BringToFront()
                // O método Activate() faz basicamente a mesma coisa que o
                // BringToFront com o adicional de dar foco no form.
            }
            else
            {
                frmExercicio5 objfrm2 = new frmExercicio5();
                objfrm2.MdiParent = this;
                objfrm2.WindowState = FormWindowState.Maximized;
                objfrm2.Show();
            }
        }
    }
}
