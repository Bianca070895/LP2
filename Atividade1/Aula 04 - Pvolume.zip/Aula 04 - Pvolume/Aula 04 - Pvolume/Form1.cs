﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula_04___Pvolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblRaio_Click(object sender, EventArgs e)
        {

        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vrlRaio, vrlAltura;

            if (!double.TryParse(txtRaio.Text, out vrlRaio) || !double.TryParse(txtAltura.Text, out vrlAltura))
            {
                 MessageBox.Show("Valores Inválidos!");
                 txtRaio.Focus();
            }
            else if (vrlRaio <= 0 || vrlAltura <= 0)
            {
                 MessageBox.Show("Valores devem ser maiores que zero");
                 txtRaio.Focus();    
            }
            else
            {
                double volume;
                //volume = 3.1415 * vrlRaio * vrlRaio * vrlAltura;
                volume = Math.PI * Math.Pow(vrlRaio, 2) * vrlAltura;
                txtVolume.Text = volume.ToString("N2");
            }

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double vrlRaio;
                if (!double.TryParse(txtRaio.Text, out vrlRaio))
            {
                MessageBox.Show("Raio Inválido!");
            }
                else
                 if (vrlRaio <= 0)
                    MessageBox.Show("Raio deve ser maior que zero!");
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double vrlAltura;
                if (!double.TryParse(txtAltura.Text, out vrlAltura))
            {
                MessageBox.Show("Altura Inválida!");
            }
            else
                 if (vrlAltura <= 0)
                MessageBox.Show("Altura deve ser maior que zero!");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
