﻿using System;

namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblAliINSS = new System.Windows.Forms.Label();
            this.lblAliIRPF = new System.Windows.Forms.Label();
            this.lblFamilia = new System.Windows.Forms.Label();
            this.lblLiquido = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.txtAliIRPF = new System.Windows.Forms.TextBox();
            this.txtFamilia = new System.Windows.Forms.TextBox();
            this.txtLiquido = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.numFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.masktxtBruto = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(42, 26);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(96, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome Funcionário:";
            this.lblNome.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblBruto
            // 
            this.lblBruto.AutoSize = true;
            this.lblBruto.Location = new System.Drawing.Point(42, 64);
            this.lblBruto.Name = "lblBruto";
            this.lblBruto.Size = new System.Drawing.Size(70, 13);
            this.lblBruto.TabIndex = 1;
            this.lblBruto.Text = "Salário Bruto:";
            this.lblBruto.Click += new System.EventHandler(this.lblBruto_Click);
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(342, 64);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(92, 13);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Numero de Filhos:";
            this.lblFilhos.Click += new System.EventHandler(this.lblFilhos_Click);
            // 
            // lblAliINSS
            // 
            this.lblAliINSS.AutoSize = true;
            this.lblAliINSS.Enabled = false;
            this.lblAliINSS.Location = new System.Drawing.Point(42, 177);
            this.lblAliINSS.Name = "lblAliINSS";
            this.lblAliINSS.Size = new System.Drawing.Size(76, 13);
            this.lblAliINSS.TabIndex = 3;
            this.lblAliINSS.Text = "Aliquota INSS:";
            this.lblAliINSS.Click += new System.EventHandler(this.lblAliINSS_Click);
            // 
            // lblAliIRPF
            // 
            this.lblAliIRPF.AutoSize = true;
            this.lblAliIRPF.Enabled = false;
            this.lblAliIRPF.Location = new System.Drawing.Point(42, 219);
            this.lblAliIRPF.Name = "lblAliIRPF";
            this.lblAliIRPF.Size = new System.Drawing.Size(75, 13);
            this.lblAliIRPF.TabIndex = 4;
            this.lblAliIRPF.Text = "Aliquota IRPF:";
            this.lblAliIRPF.Click += new System.EventHandler(this.lblAliIRPF_Click);
            // 
            // lblFamilia
            // 
            this.lblFamilia.AutoSize = true;
            this.lblFamilia.Enabled = false;
            this.lblFamilia.Location = new System.Drawing.Point(42, 264);
            this.lblFamilia.Name = "lblFamilia";
            this.lblFamilia.Size = new System.Drawing.Size(77, 13);
            this.lblFamilia.TabIndex = 5;
            this.lblFamilia.Text = "Salario Familia:";
            this.lblFamilia.Click += new System.EventHandler(this.lblFamilia_Click);
            // 
            // lblLiquido
            // 
            this.lblLiquido.AutoSize = true;
            this.lblLiquido.Enabled = false;
            this.lblLiquido.Location = new System.Drawing.Point(42, 309);
            this.lblLiquido.Name = "lblLiquido";
            this.lblLiquido.Size = new System.Drawing.Size(79, 13);
            this.lblLiquido.TabIndex = 6;
            this.lblLiquido.Text = "Salario Liquido:";
            this.lblLiquido.Click += new System.EventHandler(this.label7_Click);
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Enabled = false;
            this.lblDescINSS.Location = new System.Drawing.Point(394, 177);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(84, 13);
            this.lblDescINSS.TabIndex = 7;
            this.lblDescINSS.Text = "Desconto INSS:";
            this.lblDescINSS.Click += new System.EventHandler(this.lblDescINSS_Click);
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Enabled = false;
            this.lblDescIRPF.Location = new System.Drawing.Point(394, 219);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(83, 13);
            this.lblDescIRPF.TabIndex = 8;
            this.lblDescIRPF.Text = "Desconto IRPF:";
            this.lblDescIRPF.Click += new System.EventHandler(this.lblDescIRPF_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(145, 26);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(415, 20);
            this.txtNome.TabIndex = 9;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Enabled = false;
            this.txtAliINSS.Location = new System.Drawing.Point(145, 170);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.Size = new System.Drawing.Size(218, 20);
            this.txtAliINSS.TabIndex = 11;
            this.txtAliINSS.TextChanged += new System.EventHandler(this.txtAliINSS_TextChanged);
            // 
            // txtAliIRPF
            // 
            this.txtAliIRPF.Enabled = false;
            this.txtAliIRPF.Location = new System.Drawing.Point(145, 212);
            this.txtAliIRPF.Name = "txtAliIRPF";
            this.txtAliIRPF.Size = new System.Drawing.Size(218, 20);
            this.txtAliIRPF.TabIndex = 12;
            this.txtAliIRPF.TextChanged += new System.EventHandler(this.txtAliIRPF_TextChanged);
            // 
            // txtFamilia
            // 
            this.txtFamilia.Enabled = false;
            this.txtFamilia.Location = new System.Drawing.Point(145, 257);
            this.txtFamilia.Name = "txtFamilia";
            this.txtFamilia.Size = new System.Drawing.Size(219, 20);
            this.txtFamilia.TabIndex = 13;
            this.txtFamilia.TextChanged += new System.EventHandler(this.txtFamilia_TextChanged);
            // 
            // txtLiquido
            // 
            this.txtLiquido.Enabled = false;
            this.txtLiquido.Location = new System.Drawing.Point(145, 306);
            this.txtLiquido.Name = "txtLiquido";
            this.txtLiquido.Size = new System.Drawing.Size(218, 20);
            this.txtLiquido.TabIndex = 14;
            this.txtLiquido.TextChanged += new System.EventHandler(this.txtLiquido_TextChanged);
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(484, 174);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(76, 20);
            this.txtDescINSS.TabIndex = 15;
            this.txtDescINSS.TextChanged += new System.EventHandler(this.txtDescINSS_TextChanged);
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(483, 212);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(77, 20);
            this.txtDescIRPF.TabIndex = 16;
            this.txtDescIRPF.TextChanged += new System.EventHandler(this.txtDescIRPF_TextChanged);
            // 
            // numFilhos
            // 
            this.numFilhos.Location = new System.Drawing.Point(440, 57);
            this.numFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numFilhos.Name = "numFilhos";
            this.numFilhos.Size = new System.Drawing.Size(120, 20);
            this.numFilhos.TabIndex = 17;
            this.numFilhos.ValueChanged += new System.EventHandler(this.numFilhos_ValueChanged);
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(132, 116);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(163, 23);
            this.btnVerificar.TabIndex = 18;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.button1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(345, 116);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Limpar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // masktxtBruto
            // 
            this.masktxtBruto.Location = new System.Drawing.Point(145, 61);
            this.masktxtBruto.Mask = "99000.00";
            this.masktxtBruto.Name = "masktxtBruto";
            this.masktxtBruto.Size = new System.Drawing.Size(172, 20);
            this.masktxtBruto.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 363);
            this.Controls.Add(this.masktxtBruto);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.numFilhos);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtLiquido);
            this.Controls.Add(this.txtFamilia);
            this.Controls.Add(this.txtAliIRPF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblLiquido);
            this.Controls.Add(this.lblFamilia);
            this.Controls.Add(this.lblAliIRPF);
            this.Controls.Add(this.lblAliINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void txtAliINSS_TextChanged(object sender, EventArgs e)
        {
            
        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblAliINSS;
        private System.Windows.Forms.Label lblAliIRPF;
        private System.Windows.Forms.Label lblFamilia;
        private System.Windows.Forms.Label lblLiquido;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.TextBox txtAliIRPF;
        private System.Windows.Forms.TextBox txtFamilia;
        private System.Windows.Forms.TextBox txtLiquido;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.NumericUpDown numFilhos;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MaskedTextBox masktxtBruto;
    }
}

