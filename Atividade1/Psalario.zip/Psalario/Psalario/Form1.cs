﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblBruto_Click(object sender, EventArgs e)
        {

        }

        private void txtBruto_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblFilhos_Click(object sender, EventArgs e)
        {

        }

        private void numFilhos_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
       
            decimal salarioBruto;
            if (!decimal.TryParse(masktxtBruto.Text, out salarioBruto))
            {
                MessageBox.Show("Por favor, insira um valor válido para o salário bruto.");
                return;
            }

            decimal descontoINSS = CalcularDescontoINSS(salarioBruto);
            txtDescINSS.Text = descontoINSS.ToString("0.00");

            
            decimal descontoIRPF = CalcularDescontoIRPF(salarioBruto);
            txtDescIRPF.Text = descontoIRPF.ToString("0.00");

            
            decimal salarioFamilia = CalcularSalarioFamilia(salarioBruto);
            txtFamilia.Text = salarioFamilia.ToString("0.00");

           
            decimal salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
            txtLiquido.Text = salarioLiquido.ToString("0.00");

            if (salarioBruto <= 1257.12m)
            {
                txtAliIRPF.Text = "Isento";
            }
            else if (salarioBruto <= 2512.08m)
            {
                txtAliIRPF.Text = "15.00%";
            }
            else
            {
                txtAliIRPF.Text = "27.5%";
            }

            masktxtBruto.TextChanged += MasktxtBruto_TextChanged;

            if (salarioBruto <= 800.47m)
            {
                txtAliINSS.Text = "7.65%";
            }
            else if (salarioBruto <= 1050m)
            {
                txtAliINSS.Text = "8.65%";
            }
            else if (salarioBruto <= 1400.77m)
            {
                txtAliINSS.Text = "9.00%";
            }
            else if (salarioBruto <= 2801.56m)
            {
                txtAliINSS.Text = "11.00%";
            }
            else
            {
                txtAliINSS.Text = "TETO";
            }

            masktxtBruto.TextChanged += MasktxtBruto_TextChanged;
        }

        private void MasktxtBruto_TextChanged(object sender, EventArgs e)
        {
            
            decimal salarioBruto;
            if (decimal.TryParse(masktxtBruto.Text, out salarioBruto))
            {
                if (salarioBruto <= 800.47m)
                {
                    txtAliINSS.Text = "7.65%";
                }
                else if (salarioBruto <= 1050m)
                {
                    txtAliINSS.Text = "8.65%";
                }
                else if (salarioBruto <= 1400.77m)
                {
                    txtAliINSS.Text = "9.00%";
                }
                else if (salarioBruto <= 2801.56m)
                {
                    txtAliINSS.Text = "11.00%";
                }
                else
                {
                    txtAliINSS.Text = "TETO";
                }
            }
            else
            {
                txtAliINSS.Text = "";
            }
        }

        private decimal CalcularDescontoINSS(decimal salarioBruto)
        {
            decimal descontoINSS = 0;

            if (salarioBruto <= 800.47m)
            {
                descontoINSS = salarioBruto * 0.0765m;
            }
            else if (salarioBruto <= 1050m)
            {
                descontoINSS = salarioBruto * 0.0865m;
            }
            else if (salarioBruto <= 1400.77m)
            {
                descontoINSS = salarioBruto * 0.09m;
            }
            else if (salarioBruto <= 2801.56m)
            {
                descontoINSS = salarioBruto * 0.11m;
            }
            else
            {
                descontoINSS = 308.17m;
            }

            return descontoINSS;
        }

        private decimal CalcularDescontoIRPF(decimal salarioBruto)
        {
            decimal descontoIRPF = 0;

            if (salarioBruto > 2512.08m)
            {
                descontoIRPF = salarioBruto * 0.275m;
            }
            else if (salarioBruto > 1257.12m)
            {
                descontoIRPF = salarioBruto * 0.15m;
            }

            return descontoIRPF;
        }

        private decimal CalcularSalarioFamilia(decimal salarioBruto)
        {
            decimal salarioFamilia = 0;

            if (salarioBruto <= 435.52m)
            {
                salarioFamilia = 22.33m;
            }
            else if (salarioBruto <= 654.61m)
            {
                salarioFamilia = 15.74m;
            }

            return salarioFamilia;
        }

        private void lblAliINSS_Click(object sender, EventArgs e)
        {

        }

        private void lblDescINSS_Click(object sender, EventArgs e)
        {

        }

        private void txtDescINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblAliIRPF_Click(object sender, EventArgs e)
        {

        }

        private void txtAliIRPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblDescIRPF_Click(object sender, EventArgs e)
        {

        }

        private void txtDescIRPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblFamilia_Click(object sender, EventArgs e)
        {

        }

        private void txtFamilia_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLiquido_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            txtAliINSS.Clear();
            txtAliIRPF.Clear();
            txtDescINSS.Clear();
            txtDescIRPF.Clear();
            txtLiquido.Clear();
            txtNome.Clear();
            masktxtBruto.Clear();
            txtFamilia.Clear();
            numFilhos.ResetText();
        }
    }
}
