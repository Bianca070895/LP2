﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo__
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b, c; 

            if (double.TryParse(txtA.Text, out a) && double.TryParse(txtB.Text, out b) && double.TryParse(txtC.Text, out c))
            {
                if (a > 0 && b > 0 && c > 0)
                {
                    if (Triangulo(a, b, c)) 
                    {
                        if (a == b && b == c)
                        {
                            MessageBox.Show("O triângulo é equilátero.");
                        }
                        else if (a == b || a == c || b == c)
                        {
                            MessageBox.Show("O triângulo é isósceles.");
                        }
                        else
                        {
                            MessageBox.Show("O triângulo é escaleno.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Os valores fornecidos não podem formar um triângulo.");
                    }
                }
                else
                {
                    MessageBox.Show("Os valores não podem ser vazios ou zero.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira apenas valores numéricos válidos.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void txtA_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblLadoA_Click(object sender, EventArgs e)
        {

        }

        private void lblLadoB_Click(object sender, EventArgs e)
        {

        }

        private void txtB_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtC_TextChanged(object sender, EventArgs e)
        {

        }
        static bool Triangulo(double a, double b, double c)
        {
            return a + b > c && a + c > b && b + c > a;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
